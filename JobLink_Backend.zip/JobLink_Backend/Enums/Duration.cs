﻿namespace JobLink_Backend.Entities;

public enum Duration
{
    None = 0,
    OneHour,
    TwoHours,
    ThreeHours,
    FourHours,
    FiveHours
}