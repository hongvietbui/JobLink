namespace JobLink_Backend.Utilities.BaseEntities;

public interface IEntity
{
    
}