﻿namespace JobLink_Backend.DTOs.Request;

public class RefreshTokenRequest
{
    public string? RefreshToken { get; set; }
}