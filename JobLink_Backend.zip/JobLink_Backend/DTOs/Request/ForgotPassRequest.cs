﻿namespace JobLink_Backend.DTOs.Request
{
    public class ForgotPassRequest
    {
        public string Email { get; set; }
    }
}
