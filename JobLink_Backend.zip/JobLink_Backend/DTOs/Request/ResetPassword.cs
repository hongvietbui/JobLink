﻿namespace JobLink_Backend.DTOs.Request
{
    public class ResetPassword
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
