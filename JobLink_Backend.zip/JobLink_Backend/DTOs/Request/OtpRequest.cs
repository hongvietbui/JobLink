﻿namespace JobLink_Backend.DTOs.Request
{
    public class OtpRequest
    {
        public string Email { get; set; }
        public string Code { get; set; }
    }
}
