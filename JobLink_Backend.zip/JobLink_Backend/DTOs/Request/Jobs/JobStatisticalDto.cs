namespace JobLink_Backend.DTOs.Request.Jobs;

public class JobStatisticalDto
{
    public DateTime From { get; set; }
    public DateTime To { get; set; }
}