﻿namespace JobLink_Backend.DTOs.Response;

public class QRData
{
    public string QrCode { get; set; }
    public string QrDataURL { get; set; }
}