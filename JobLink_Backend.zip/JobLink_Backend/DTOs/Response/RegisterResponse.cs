﻿namespace JobLink_Backend.DTOs.Response;

public class RegisterResponse
{
    
}