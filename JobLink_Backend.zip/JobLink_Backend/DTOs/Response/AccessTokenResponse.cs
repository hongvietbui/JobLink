﻿namespace JobLink_Backend.DTOs.Response;

public class AccessTokenResponse
{
    public string AccessToken { get; set; }
}