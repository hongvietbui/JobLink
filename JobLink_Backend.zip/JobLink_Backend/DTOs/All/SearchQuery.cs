namespace JobLink_Backend.DTOs.All;

public class SearchQuery
{
    public string? Query { get; set; }
}
