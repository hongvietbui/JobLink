﻿namespace JobLink_Backend.DTOs.All;

public class RoleDTO
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}