﻿using AutoMapper;

namespace JobLink_Backend.Mappings;

public abstract class MapProfile : Profile
{
}