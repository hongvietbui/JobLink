﻿using JobLink_Backend.Entities;

namespace JobLink_Backend.Repositories.IRepositories;

public interface IJobRepository : IRepository<Job>
{
    
}