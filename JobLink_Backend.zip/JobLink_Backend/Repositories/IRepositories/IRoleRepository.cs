﻿using JobLink_Backend.Entities;

namespace JobLink_Backend.Repositories.IRepositories;

public interface IRoleRepository : IRepository<Role>
{
    
}